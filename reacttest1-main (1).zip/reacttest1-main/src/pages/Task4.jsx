import BookList from "../components/BookList.jsx";

const Task4 = () => {
    return(<BookList/>)
}



export default Task4;